const Issue = require('../models/issue-model');
const multer = require('../middlewares/multer');

const issueForm = async (req, res) => {
  try {
    const { issueDate, username, userId, type, assignTo, query, priorityLevel, location } = req.body;

    const filePaths = req.files ? req.files.map(file => file.path) : [];
// console.log(issueDate);
// console.log(req.files);
// console.log(filePaths);

    const newIssue = new Issue({
      issueDate,
      username,
      userId,
      type,
      assignTo,
      query,
      priorityLevel,
      location,
      attachments: filePaths,
    });

    await newIssue.save();
    // await Issue.save();
    return res.status(201).json(newIssue);
  } catch (error) {
    console.error('Error in issueForm:', error);
    return res.status(500).json({ message: 'Error from issue-controller', error });
  }
};

module.exports = issueForm;
