const User = require("../models/user-model")
const bcrypt = require("bcryptjs");
const { v4: uuidv4 } = require("uuid");
const moment = require("moment");


const home = async (req, res) => {
try{
    res.status(200).send('Wellcome to router');
}catch (errror){
    res.send(400).send({msg:"Page not found"})

}
}

const generateUserId = async (username) => {
    const year = moment().format("YYYY");
    const prefix = username.slice(0, 2).toUpperCase();
  
    // Find the highest existing suffix for this prefix and year
    const existingUser = await User.findOne({
      userId: new RegExp(`^${year}${prefix}`),
    }).sort({ userId: -1 });
  
    const suffix = existingUser
      ? parseInt(existingUser.userId.slice(-4)) + 1
      : 1;
  
    return `${year}${prefix}${suffix.toString().padStart(4, '0')}`;
  };
  

const register = async (req, res) => {
try{
    console.log(req.body);
    const {username, email, phone, password} = req.body;

    const userExist = await User.findOne({email: email});

    if(userExist){
        return res.status(400).json({msg:"email already exist"});
    }

    const userId = await generateUserId(username);
   
    const userCreated = await User.create({
        userId,
        username,
        email,
        phone,
        password,
    });

    res.status(201).json({ msg: "Registration Successful", 
                           token: await userCreated.generateToken(),
                           userId: userCreated._id.toString(),
});
}catch (error) {
    next(error);
}
}



 // LOGIN LOGIC
 const login = async (req, res) => {
try {
    const { email, password } = req.body;
    
    const userExist = await User.findOne({ email });
    console.log(userExist);
    //If user not exist
    if(!userExist){
       return res.status(400).json({message: "Invalid Credentials" }); 
    }
    const user = await userExist.comparePassword(password);

    if(user){
        res.status(200).json({
            msg: "Login Successful",
            token: await userExist.generateToken(),
            _id: userExist._id.toString(),
            userId: userExist.userId,
            username: userExist.username,
            assignee: userExist.isAssignee,
            manager: userExist.isManager,
        });
    }else{
        res.status(401).json({message: "Invalid Email or Password"});
    }


} catch (error) {
    res.status(500).json("Internal server error");
    }
 };
 

//To send the user data to the site
const user = async (req, res) => {
    try {
        const userData = req.user;
        return res.status(200).json({
            userId: userData.userId,
            username: userData.username,
            email: userData.email,
            phone: userData.phone
        });
    } catch (error) {
        console.log(error);
    }
};

const feedback = async (req, res) => {
    try {
        const feedbackData = req.feedback;
        console.log(feedbackData);
        return res.status(200).json({});
    } catch (error) {
        console.log(error);
    }
}


module.exports = { home, register, login, user, feedback};
