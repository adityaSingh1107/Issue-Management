const User = require('../models/user-model');

// Get details of the currently logged-in user
exports.getUserDetails = async (req, res) => {
    console.log("getUserDetails function called");
    try {
        // Ensure that req.user is populated by the auth middleware
        if (!req.user || !req.user._id) {
            return res.status(401).json({ message: 'Unauthorized, User ID not found' });
        }

        // Fetch the user from the database using req.user._id
        const user = await User.findById(req.user._id).select('username email  UserId '); // Adjust fields as needed
        console.log("User fetched from DB:", user);
        
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.status(200).json(user);
    } catch (error) {
        console.error('Error fetching user details:', error);
        res.status(500).json({ message: 'Failed to retrieve user details', error });
    }
};


// Delete user by ID
exports.deleteUser = async (req, res) => {
    try {
        const userId = req.params.id;
        await User.findByIdAndDelete(userId);
        res.status(200).json({ message: 'User deleted successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Failed to delete user', error });
    }
};

// Promote user (toggle isAdmin or isAssignee)
exports.promoteUser = async (req, res) => {
    try {
        const { userId, promoteTo } = req.body;
        const updateFields = {};
        
        if (promoteTo === 'admin') {
            updateFields.isAdmin = true;
        } else if (promoteTo === 'assignee') {
            updateFields.isAssignee = true;
        }
        
        const user = await User.findByIdAndUpdate(userId, updateFields, { new: true });
        res.status(200).json(user);
    } catch (error) {
        res.status(500).json({ message: 'Failed to promote user', error });
    }
};

// Demote user (remove from admin or assignee)
exports.demoteUser = async (req, res) => {
    try {
        const { userId, demoteFrom } = req.body;
        const updateFields = {};

        if (demoteFrom === 'admin') {
            updateFields.isAdmin = false;
        } else if (demoteFrom === 'assignee') {
            updateFields.isAssignee = false;
        }

        const user = await User.findByIdAndUpdate(userId, updateFields, { new: true });
        res.status(200).json(user);
    } catch (error) {
        res.status(500).json({ message: 'Failed to demote user', error });
    }
};


// Update user by ID
exports.updateUser = async (req, res) => {
    try {
        const userId = req.params.id;
        const updateFields = req.body;

        // Check if userId and updateFields are provided
        if (!userId) {
            return res.status(400).json({ message: 'User ID is required' });
        }

        if (!updateFields || Object.keys(updateFields).length === 0) {
            return res.status(400).json({ message: 'No fields to update' });
        }

        const updatedUser = await User.findByIdAndUpdate(userId, updateFields, { new: true });

        if (!updatedUser) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.status(200).json(updatedUser);
    } catch (error) {
        console.log(error);
        res.status(500).json({ message: 'Failed to update user', error });
    }
};
