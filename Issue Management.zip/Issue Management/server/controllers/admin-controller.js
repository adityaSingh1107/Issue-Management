const User = require("../models/user-model");
const Issue = require("../models/issue-model");
const { response } = require("express");


// Exporting User data from Database to admin
const getAllUsers = async (req, res) => {
try {
    const users = await User.find();
    return res.status(200).json(users);
} catch (error) {
    return res.status(500).json({message: "Data not delivered" });
}
};

//User delete logic by Admin
const deleteUserById = async(req,res) =>{
    try {
        const id =  req.params.id;
        await User.deleteOne({ _id: id });
        return res.status(200).json({message:"User Deleted Successfully"});
    } catch (error) {
        next(error);
    }
 
};



//Exporting Issues from Database to the admin
const getAllIssue = async(req, res) => {
    try {
        const issue = await Issue.find();
        return res.status(200).json(issue);
    } catch (error) {
        return res.status(500).json({message: "Data not delivered" });
    }
}


const getIssue = async(req,res) =>{
    try {
        const id =  req.params.id;
        const issue = await Issue.findById({_id: id});
        return res.status(200).json(issue);
    } catch (error) {
        return res.status(404).json({"message":"Issue was not found"});
    }
}

const getAllResponse = async (req, res) => {
    try {
        const id =  req.params.id;
        const issue = await Issue.findById({_id: id});
        return res.status(200).json(issue);
    } catch (error) {
        return res.status(404).json({"message":"Issue was not found"});
    }
 };

 const commentUserById = async (req, res) => {
    try {
        const id =  req.params.id;
        const issue = await Issue.findById({_id: id});
        console.log(req.body);
        issue.comment = req.body.comment;
        issue.save();
        return res.status(200).json(issue);
    } catch (error) {
        return res.status(404).json({"message":"Issue was not found"});
    }
 };

//  const commentUserById = async (req, res) => {
//     try {
//         const id =  req.params.id;
//         const issue = await Issue.findById({_id: id});
//         console.log(req.body);
//         response.comment = req.body.comment;
//         response.save();
//         return res.status(200).json(response);
//     } catch (error) {
//         return res.status(404).json({"message":"Issue was not found"});
//     }
//  };
 


module.exports = { getAllUsers, getAllIssue, deleteUserById, getIssue, getAllResponse, commentUserById};