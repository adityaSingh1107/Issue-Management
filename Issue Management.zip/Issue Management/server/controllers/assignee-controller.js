const Assignee = require('../models/assignee-model');
const multer = require('../middlewares/multer');

const assigneeForm = async (req, res) => {
  try {
    const { issueDate,username, assignTo, type, query, priorityLevel, location, comment} = req.body;
    const filePaths = req.files ? req.files.map(file => file.path) : [];

    const newAssignee = new Assignee({
      issueDate,
      username,
      assignTo,
      type,
      query,
      priorityLevel,
      location,
      comment,
      attachments: filePaths,
    });

    await newAssignee.save();
    return res.status(201).json(newAssignee);
  } catch (error) {
    console.error('Error from assignee-controller post:', error);
    return res.status(500).json({ message: 'Error from assignee-controller post', error: error.message});
  }
};

const getAllAssignees = async (req, res) => {
  try {
    console.log("get req", req);
    const allAssignees = await Assignee.find();
    console.log(allAssignees); 
    res.status(200).json(allAssignees);
  } catch (error) {
    console.error('Error fetching assignees:', error);
    res.status(500).json({ message: 'Error fetching assignees', error: error.message });
  }
};

module.exports = {assigneeForm, getAllAssignees};
