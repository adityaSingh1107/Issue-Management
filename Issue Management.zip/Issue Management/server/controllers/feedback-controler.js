const Feedback = require("../models/feedback-model");

const feedback = async (req, res) => {
    try {
        const response = req.body
        await Feedback.create(response);
        return res.status(200).json({message: "Message send successfully" });
    } catch (error) {
        return res.status(500).json({message: "Message not delivered" });
    }
};

module.exports = feedback;

