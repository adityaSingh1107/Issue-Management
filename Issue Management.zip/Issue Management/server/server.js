require("dotenv").config();

const express = require("express");

const cors = require("cors");

const app = express();

const contactRoute = require("./router/contact-router");

const authRoute = require("./router/auth_route");

const issueRoute = require("./router/issue-router");

const adminRoute = require("./router/admin-route");

const userRoutes = require('./router/user-route');

const logoutRoute = require('./router/logout-router');

const feedbackRoutes = require("./router/feedback-route");

// const assigneeRoute = require('./router/assignee-router');
const assigneeRoute = require('./router/assignee-router');

const connectDb = require("./utils/db");

const errorMiddleware = require("./middlewares/error-middleware");
const { feedback } = require("./controllers/auth_controller");


const corsOptions = {
    origin: "http://localhost:5173",
    methods: "GET, POST, PUT, DELETE, PATCH, HEAD",
    credentials: true,
}
app.use(cors(corsOptions));

app.use(express.json());


app.use("/api/auth", authRoute);

app.use("/api/form", contactRoute);

app.use("/api/issues", issueRoute);

app.use("/api/admin", adminRoute);

app.use('/api/admin', userRoutes);

app.use('/api/logout', logoutRoute);

// app.use('/api/assignee', assigneeRoute);
app.use("/api/assignee", assigneeRoute);

app.use("/api/feedback", feedbackRoutes)

app.use(errorMiddleware);

const PORT = 5000;

connectDb().then(() => {
    app.listen(PORT, () => {
        console.log(`Server is running at port: ${PORT}`);
    });
});

