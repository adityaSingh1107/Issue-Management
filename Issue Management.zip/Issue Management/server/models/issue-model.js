const mongoose = require("mongoose");

const issueSchema = new mongoose.Schema({
    issueDate: {
        type: String,
        required: true,
    },
    username: {
        type: String,
        required: true,
    },
    userId: {
        type: String,
        required: true,
    },
    type: {
        type: String,
        required: true,
    },
    assignTo: {
        type: String,
        required: true,
    },
    query: {
        type: String,
        required: true,
    },
    priorityLevel: {
        type: String,
        required: true,
    },
    location: {
        type: String,
        required: true,
    },
    attachments: [String],
    
});
const Issue = new mongoose.model("Issue", issueSchema);
module.exports = Issue;