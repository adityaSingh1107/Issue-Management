const mongoose = require("mongoose");

const assigneeSchema = new mongoose.Schema({
   
    issueDate: {
        type: String,
        required: true,
    },
    username: {
        type: String,
        required: true,
    },
    type: {
        type: String,
        required: true,
    },
    assignTo: {
        type: String,
        required: true,
    },
    query: {
        type: String,
        required: true,
    },
    priorityLevel: {
        type: String,
        required: true,
    },
    location: {
        type: String,
        required: true,
    },
    comment: {
        type: String,
        required: true,
    },
    // comments: [commentSchema],
    attachments: [String],
    
});
const Assignee = new mongoose.model("Assignee", assigneeSchema);
module.exports = Assignee;
