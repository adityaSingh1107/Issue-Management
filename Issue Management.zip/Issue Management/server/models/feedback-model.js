const mongoose = require("mongoose");

const feedbackSchema = new mongoose.Schema({
    
    // rate: Number,
    // comments: String
     overallExperience: {
    type: Number,
    required: true,
    // min: 1,
    // max: 5,
  },
  designRating: {
    type: Number,
    required: true,
    // min: 1,
    // max: 5,
  },
  loadingTimeRating: {
    type: Number,
    required: true,
    // min: 1,
    // max: 5,
  },
  comments: {
    type: String,
    required: false,
  },
  });

  const Feedback = mongoose.model('Feedback', feedbackSchema);
  module.exports = Feedback;