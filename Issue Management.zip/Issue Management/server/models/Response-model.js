const mongoose = require("mongoose");
const responseSchema = new mongoose.Schema({
    issueDate: {
        type: String,
        required: true,
    },
    username: {
        type: String,
        required: false,
    },
    type: {
        type: String,
        required: true,
    },
    assignTo: {
        type: String,
        required: true,
    },
    query: {
        type: String,
        required: true,
    },
    priorityLevel: {
        type: String,
        required: true,
    },
    location: {
        type: String,
        required: true,
    },
    remark: {
        type: String,
        required: true,
    },
});
const Response = new mongoose.model("Response", responseSchema);
module.exports = Response;