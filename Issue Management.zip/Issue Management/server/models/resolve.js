const mongoose = require("mongoose");

const resolveSchema = new mongoose.Schema({
    issueDate: {
        type: String,
        required: true,
    },
    username: {
        type: String,
        required: true,
    },
    type: {
        type: String,
        required: true,
    },
    assignTo: {
        type: String,
        required: true,
    },
    query: {
        type: String,
        required: true,
    },
    priorityLevel: {
        type: String,
        required: true,
    },
    location: {
        type: String,
        required: true,
    },
    attachments: [String],
    
});
const Resolve = new mongoose.model("Resolve", resolveSchema);
module.exports = Resolve;