const { z } = require("zod");

//Creating an object schema
const signupSchema = z.object({
    username: z
    .string({required_error: "Name is required"})
    .trim()
    .min(3, {message: "Name is must be at least of 3 Characters.."})
    .max(25, {message: "Name must not be more than 25 Characters"}),

    email: z
    .string({ required_error: "Email is required"})
    .trim()
    .email({ messaged: "Invalid email address" })
    .max(50, {message: "Email must not be more than 50 characters"}),

    phone: z
    .string({required_error: "Phone is required"})
    .trim()
    .length(10, {message: "Phone must be at least of 10 characters"})
    .regex(/^\d+$/, { message: "Phone number must contain only digits" }),

    password: z
    .string({ required_error: "Password is required"})
    .min(6, {message: "Password must be at last of 6 characters"})
    .max(12, "Password can't be greater than 12 characters")
    .regex(/[A-Z]/, { message: "Password must contain at least one uppercase letter" }) // Optional complexity requirement
    .regex(/[a-z]/, { message: "Password must contain at least one lowercase letter" }) // Optional complexity requirement
    .regex(/[0-9]/, { message: "Password must contain at least one number" }) // Optional complexity requirement
    .regex(/[\W_]/, { message: "Password must contain at least one special character" }) // Optional complexity requirement
});


module.exports = signupSchema;

