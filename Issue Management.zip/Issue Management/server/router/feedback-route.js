const express =require("express");
const router = express.Router(); 
const feedback = require("../controllers/feedback-controler");


router.route("/feedback").post(feedback);


module.exports = router;
