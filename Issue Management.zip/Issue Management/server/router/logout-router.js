const express = require('express');
const router = express.Router();
const { addToBlacklist } = require('../tokenBlacklist');

// Logout route
router.post('/logout', (req, res) => {
    const token = req.header('Authorization');
    
    if (!token || !token.startsWith('Bearer ')) {
        return res.status(400).json({ message: "Bad Request, Token not provided" });
    }

    const jwtToken = token.replace("Bearer ", "").trim();
    addToBlacklist(jwtToken);

    res.status(200).json({ message: "Logged out successfully" });
});

module.exports = router;
