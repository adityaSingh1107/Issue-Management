const express =require("express");
const router = express.Router(); 
const issueForm = require("../controllers/issue-controller");
const multer = require('multer');
const path = require('path');
const authMiddleware = require('../middlewares/auth-middleware');

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
      cb(null, Date.now() + '-'+file.originalname);
    }
  });
  

const upload = multer({storage:storage});
// Route to handle file upload and issue upload 
router.route("/issue").post(upload.array('attachments'),issueForm);


// Route to serve files for download

// router.get('/download/:filename', (req, res) => {
//   const filename = req.params.filename;
//   const filePath = path.join(__dirname, '../uploads', filename);

//   console.log(`File path: ${filePath}`);

//   res.download(filePath, (err) => {
//     if (err) {
//       res.status(404).send('File not found');
//     }
//   });
// });



module.exports = router;


