const jwt = require('jsonwebtoken');
const User = require('../models/user-model');

const login = async (req, res) => {
    const { email, password } = req.body;

    const user = await User.findOne({ email });
    if (!user || !user.validatePassword(password)) {
        return res.status(401).json({ message: 'Invalid credentials' });
    }

    const secretKey = "TATAPROJECTSECRETKEYMUSTBEOFTHIRTYTWOCHARACTERS";
    const token = jwt.sign({ email: user.email, username: user.username }, secretKey, { expiresIn: '1d' });

    res.json({ token, user });
    console.log(token);
};
