const express =require("express");
const router = express.Router(); 
// const assigneeForm = require("../controllers/assignee-controller");
// const getAllAssignees = require("../controllers/assignee-controller");
const { assigneeForm, getAllAssignees} = require("../controllers/assignee-controller");
const multer = require('multer');



const storage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
      cb(null, Date.now() + '-'+file.originalname);
    }
  });
  

const upload = multer({storage:storage});

// router.route("/assignee").post(upload.array('attachments'),assigneeForm);
router.route("/").get(getAllAssignees);
router.route("/").post(upload.array('attachments'), assigneeForm);



module.exports = router;
