const express = require('express');
const adminController = require("../controllers/admin-controller");
const router = express.Router();
const authMiddleware = require("../middlewares/auth-middleware");
const adminMiddleware = require('../middlewares/admin-middleware');

router.route("/users").get( authMiddleware, adminMiddleware, adminController.getAllUsers);

router.route("/issues").get(authMiddleware, adminMiddleware,adminController.getAllIssue);

router.route("/issues/:id").get(authMiddleware, adminMiddleware,adminController.getIssue);

router.route("/issue/comment/:id").post(authMiddleware, adminMiddleware, adminController.commentUserById);

// router.route("/response/comment/:id").post(authMiddleware, adminMiddleware, adminController.commentUserById);

module.exports = router;