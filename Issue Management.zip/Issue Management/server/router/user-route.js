const express = require('express');
const { deleteUser, promoteUser, demoteUser, updateUser, getUserDetails } = require('../controllers/user-controller');
const authMiddleware = require('../middlewares/auth-middleware');
const router = express.Router();

// Middleware to authenticate admin, adjust as needed
const authenticateAdmin = (req, res, next) => {
    // Implement your admin authentication logic herea
    next();
};

router.get('/users/loginUser', authMiddleware, getUserDetails);

router.delete('/users/:id', authenticateAdmin, deleteUser);

router.put('/users/:id', authenticateAdmin, updateUser);

router.put('/users/promote', authenticateAdmin, promoteUser);

router.put('/users/demote', authenticateAdmin, demoteUser);

// router.get('/user/details', authMiddleware, getUserDetails);

router.get('/user/details', authMiddleware, getUserDetails);


module.exports = router;
