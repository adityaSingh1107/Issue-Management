const express = require('express');
const multer = require('multer');
const path = require('path');

const app = express();

// Define the storage configuration for multer
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/'); // Destination folder for uploads
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname); // Extract file extension
    cb(null, file.fieldname + '-' + Date.now() + ext); // Create a unique filename
  }
});

// Create an instance of multer with the storage configuration
const upload = multer({ storage: storage }).array('attachments'); // 'attachments' is the name of the input field

// Define the POST route for file uploads
app.post('/uploads', (req, res) => {
  upload(req, res, (err) => {
    if (err) {
      return res.status(500).json({ message: 'File upload failed', error: err });
    }
    // Handle the uploaded files here (e.g., save details to the database)
    res.status(200).json({ message: 'Files uploaded successfully', files: req.files });
  });
});

// Start the server
// const PORT = process.env.PORT || 3000;
// app.listen(PORT, () => {
//   console.log(`Server is running on port ${PORT}`);
// });
