const jwt = require("jsonwebtoken");
const User = require("../models/user-model");
const { isBlacklisted } = require("../tokenBlacklist");

const authMiddleware = async(req, res, next) =>{
    
    // Extracting the Authorization header
    try{
    const token = req.header('Authorization');

        if (!token) {
            return res.status(401).json({message:"Unauthorized HTTP, Token not provided"});
        }
        // console.log('Raw token',token);

        // Checking if the Authorization header starts with 'Bearer '
        if (!token.startsWith('Bearer ')) {
            return res.status(401).json({ message: "Unauthorized HTTP, Token format is incorrect" });
        }

        const jwtToken = token.replace("Bearer ", "").trim();

          // Check if token is blacklisted
          if (isBlacklisted(jwtToken)) {
            return res.status(401).json({ message: "Unauthorized, Token is invalidated" });
        }

             // Verify the JWT
            const secretKey = "TATAPROJECTSECRETKEYMUSTBEOFTHIRTYTWOCHARACTERS";
            const isVerified = jwt.verify(jwtToken, secretKey);
            console.log(isVerified);

            // Fetch the user from the database
            const userData = await User.findOne({email: isVerified.email}).
            select({
                password: 0,
            });
            if (!userData) {
                return res.status(404).json({ message: "User not found" });
            }
            console.log(userData);

            // Attach the user and token to the request object
            req.user = userData;
            req.token = jwtToken;
            req.userID = userData._id;
            // req.username = isVerified.username;

            next();
        } catch (error) {
            // console.error('Token Verification Error:', error);
            return res.status(401).json({message: "Unauthorized Invalid Token."});
        }
};


module.exports = authMiddleware;