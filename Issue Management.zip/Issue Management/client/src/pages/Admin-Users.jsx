import { useEffect, useState } from "react";

export const AdminUsers = () => {
  const [users, setUsers] = useState([]);
  const [editingUser, setEditingUser] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [updatedUser, setUpdatedUser] = useState({
    phone: "",
    isAdmin: false,
    isAssignee: false,
  });

  const getAllUsersData = async () => {
    try {
      const response = await fetch("http://localhost:5000/api/admin/users", {
        method: "GET",
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      const data = await response.json();
      setUsers(data);
    } catch (error) {
      console.error("Failed to fetch users:", error);
    }
  };

  const deleteUser = async (userId) => {
    try {
      await fetch(`http://localhost:5000/api/admin/users/${userId}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      setUsers(users.filter((user) => user._id !== userId));
    } catch (error) {
      console.error("Failed to delete user:", error);
    }
  };

  const handleEditClick = (user) => {
    setEditingUser(user);
    setUpdatedUser({
      phone: user.phone,
      isAdmin: user.isAdmin,
      isAssignee: user.isAssignee,
      isManager: user.isAssignee,
    });
    setModalVisible(true);
  };

  const updateUser = async () => {
    try {
      const response = await fetch(
        `http://localhost:5000/api/admin/users/${editingUser._id}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
          body: JSON.stringify(updatedUser),
        }
      );

      if (response.ok) {
        const updatedData = await response.json();
        setUsers(
          users.map((user) =>
            user._id === updatedData._id ? updatedData : user
          )
        );
        setModalVisible(false);
      } else {
        console.error("Failed to update user. Status code:", response.status);
      }
    } catch (error) {
      console.error("Failed to update user:", error);
    }
  };

  useEffect(() => {
    getAllUsersData();
  }, []);

  return (
    <>
      <section className="admin-user-section">
        <div className="heading-admin-user">
          <h1>User Data Table</h1>
        </div>
        <div className="container admin-user">
          <table>
            <thead>
              <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map((curUser) => (
                <tr key={curUser._id}>
                  <td>{curUser.userId}</td>
                  <td>{curUser.username}</td>
                  <td>{curUser.email}</td>
                  <td>{curUser.phone}</td>
                  <td>
                    <button onClick={() => handleEditClick(curUser)}>
                      Edit
                    </button>
                    <button onClick={() => deleteUser(curUser._id)}>
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {modalVisible && (
        <div className="modal">
          <div className="modal-content">
            <h2>Edit User</h2>
            <label>
              Phone:
              <input
                type="text"
                value={updatedUser.phone}
                onChange={(e) =>
                  setUpdatedUser({ ...updatedUser, phone: e.target.value })
                }
              />
            </label>
            <div>
              <label>
                <input
                  type="checkbox"
                  name="role"
                  checked={updatedUser.isManager}
                  onChange={() =>
                    setUpdatedUser({ ...updatedUser, isManager: true, isAssignee: false })
                  }
                />
                Manager
              </label>
              <label>
                <input
                  type="checkbox"
                  name="role"
                  checked={updatedUser.isAssignee}
                  onChange={() =>
                    setUpdatedUser({ ...updatedUser, isAssignee: true, isManager: false })
                  }
                />
                Assignee
              </label>
              {/* <label>
                <input
                  type="checkbox"
                  name="role"
                  checked={!updatedUser.isAdmin && !updatedUser.isAssignee}
                  onChange={() =>
                    setUpdatedUser({ ...updatedUser, isAdmin: true })
                  }
                />
                User
              </label> */}
            </div>
            <button onClick={updateUser}>Submit</button>
            <button onClick={() => setModalVisible(false)}>Cancel</button>
          </div>
        </div>
      )}
    </>
  );
};

