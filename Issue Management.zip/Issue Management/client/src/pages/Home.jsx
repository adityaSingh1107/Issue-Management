// // // // import { useState, useEffect } from "react";
// // // export const Home = () => {
// // //   return (
// // //     <>
// // //       <main>
// // //         <section className="section-home">
// // //             <div className="home-content">
           
// // //               <br />
// // //               <h1>"Connect, Ask, and Get Answers: Welcome to QueryConnect!"</h1>
// // //               <br />
// // //               <p id="dynamic-text">
// // //                 Welcome to QueryConnect! Our platform simplifies your search for
// // //                 answers by connecting you with experts in various fields.
// // //                 Register now to submit your questions, track responses, and
// // //                 engage with a community of knowledgeable professionals. Get the
// // //                 insights you need, quickly and efficiently!
// // //               </p>
            
// // //               <div className="home-btn-group">
// // //                 <a href="/contact">
// // //                   <button className="btn">Connect Now</button>
// // //                 </a>
// // //                 <a href="/about">
// // //                   <button className="btn-secondary-btn">Learn More</button>
// // //                 </a>
// // //               </div>
// // //             </div> 

           
// // //         </section>
// // //       </main>
// // //     </>
// // //   );
// // // };

// // import React from 'react';
// // import { PieChart, Pie, Tooltip, ResponsiveContainer } from 'recharts';

// // export const Home = () => {

// // const data = [
// //   { name: 'Group A', value: 400 },
// //   { name: 'Group B', value: 300 },
// //   { name: 'Group C', value: 300 },
// //   { name: 'Group D', value: 200 },
// // ];

// // const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];


// //   function App(){
// //     return (
// //       <ResponsiveContainer width="100%" height="100%">
// //         <PieChart width={400} height={400}>
// //           <Pie
// //             dataKey="value"
// //             isAnimationActive={false}
// //             data={data}
// //             cx="50%"
// //             cy="50%"
// //             outerRadius={80}
// //             fill="#0088FE"
// //             label
// //           />
// //           {/* <Pie dataKey="value" data={data02} cx={500} cy={200} innerRadius={40} outerRadius={80} fill="#82ca9d" /> */}
// //           <Tooltip />
// //         </PieChart>
// //       </ResponsiveContainer>
// //     );
// //   }

// // }

// import React from 'react';
// import { PieChart, Pie, Tooltip, ResponsiveContainer } from 'recharts';
// import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Legend } from 'recharts';


// const data = [
//   { name: 'Group A', value: 400 },
//   { name: 'Group B', value: 300 },
//   { name: 'Group C', value: 300 },
//   { name: 'Group D', value: 200 },
// ];


// // const getColor = (name) => {
// //   const homePageStyle = getComputedStyle(document.querySelector('.container-home'));
// //   return homePageStyle.getPropertyValue(`--color-${name.toLowerCase().replace(' ', '-')}`).trim() || '#8884d8';
// // };

// const colorMap = {
//   'Group A': '#ff0000',
//   'Group B': '#00C49F',
//   'Group C': '#FFBB28',
//   'Group D': '#FF8042',
// };

// export const Home = () => {
//   return (
//     <div className="container-home">
//       <div className="chart-container-home">
//         <h2>Pie Chart</h2>
//         <ResponsiveContainer width="100%" height={400}>
//           <PieChart>
//             <Pie
//               dataKey="value"
//               isAnimationActive={false}
//               data={data}
//               cx="50%"
//               cy="50%"
//               outerRadius={120}
//               label
//               fill="#8884d8"
//               // fill={({ name }) => getColor(name)} 
//               // fill={({ name }) => colorMap[name] || '#8884d8'} 
//             />
//             <Tooltip />
//           </PieChart>
//         </ResponsiveContainer>
//       </div>
//       <div className="chart-container-home">
//         <h2>Bar Chart</h2>
//         <ResponsiveContainer width="100%" height={400}>
//           <BarChart
//             data={data}
//             layout="vertical"
//             margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
//           >
//             <CartesianGrid strokeDasharray="3 3" />
//             <XAxis type="number" />
//             <YAxis type="category" dataKey="name" />
//             <Tooltip />
//             <Legend />
//             {/* <Bar dataKey="value" fill={({ name }) => getColor(name)}  /> */}
//             <Bar
//              dataKey="value"
//             //  fill={({ name }) => colorMap[name] || '#ff0000'} 
//             fill="#ff0000"
//             />
//           </BarChart>
//         </ResponsiveContainer>
//       </div>
//     </div>
//   );
// };
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import {
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

export const Home = () => {

  const { id } = useParams();
  const [issues, setIssues] = useState([]);
  const [assignees, setAssignees] = useState([]);
  const [assigneesCount, setAssigneesCount] = useState(0);

  useEffect(() => {
    // Fetch issues data
    const fetchIssues = async () => {
      try {
        const response = await fetch("http://localhost:5000/api/admin/issues", {
          method: "GET",
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        });

        if (response.ok) {
          const data = await response.json();
          if (Array.isArray(data)) {
            setIssues(data);
          } else {
            console.error("Unexpected data format for issues:", data);
          }
        } else {
          console.error("Error fetching issues:", response.statusText);
        }
      } catch (error) {
        console.error("Error fetching issues:", error);
      }
    };

    fetchIssues();
  }, [id]);

  useEffect(() => {
    // Fetch assignees data
    const fetchAssignees = async () => {
      try {
        const response = await fetch("http://localhost:5000/api/assignee", {
          method: "GET",
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json",
          },
        });

        if (response.ok) {
          const data = await response.json();
          setAssignees(data);
          setAssigneesCount(data.length);
        } else {
          console.error("Error fetching assignees:", response.statusText);
        }
      } catch (error) {
        console.error("Error fetching assignees:", error);
      }
    };

    fetchAssignees();
  }, []);

  const totalIssues = issues.length;

  // Data for Pie Chart
  const pieData = [
    { name: "Total Issues Register", value: totalIssues },
    { name: "Total Issue Attempted", value: assigneesCount },
  ];

  // Data for Bar Chart
  const barData = [
    { name: "Total Issues Register", count: totalIssues },
    { name: "Total Issue Attempted", count: assigneesCount },
  ];

  return (
    <div className="issues-dashboard">
      <div className="summary">
        {/* <p>Total Issues Register: {totalIssues}</p>
        <p>Total Issue Attempted: {assigneesCount}</p> */}
        <p>Welcome to ISSUE MANAGEMENT...!</p> 
        <p>We’re thrilled you’re here.</p>
      </div>

      <div className="issues-dashboard__charts">
        <div className="issues-dashboard__chart issues-dashboard__pie-chart">
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={pieData}
                dataKey="value"
                nameKey="name"
                outerRadius={100}
                fill="#8884d8"
                label
              >
                {pieData.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={index === 0 ? "#d42215" : "#82ca9d"}
                  />
                ))}
              </Pie>
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="issues-dashboard__chart issues-dashboard__bar-chart">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart
              data={barData}
              margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
            >
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="count" fill="#8884d8" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

