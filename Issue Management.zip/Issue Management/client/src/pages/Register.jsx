import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../store/auth";

const URL = "http://localhost:5000/api/auth/Register";

export const Register = () => {
  const [user, setUser] = useState({
    username: "",
    email: "",
    phone: "",
    password: "",
  });

  const navigate = useNavigate();

  const { storeTokenInLS } = useAuth();

  const handleInput = (e) => {
    console.log(e);
    let name = e.target.name;
    let value = e.target.value;

    setUser({
      ...user,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log(user);
    try {
      const response = await fetch(URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(user),
      });

      if (response.ok) {
        const res_data = await response.json();
        console.log("Response From Server", res_data);
        storeTokenInLS(res_data.token);
        alert("Successful Registration");
        setUser({username: "", email: "", phone: "", password: "" });
        navigate("/");
      } else {
        alert("This email address is already registered");
      }
    } catch (error) {
      console.log("register ", error);
    }
  };

  return (
    <>
      <section>
        <main>
          <div className="section-registration">
            {/* <div className="container grid grid-two-cols"> */}
              {/* <div className="register-info">
                <p>1. Password Requirements:</p>
                <p>Length: Must be at least 8 characters long.</p>
                <p>
                  Uppercase Letter: Must contain at least one uppercase letter
                  (A-Z).
                </p>
                <p>
                  Special Character: Must include at least one special character
                  (e.g., @, #, $, %, &, *).
                </p>
                <p>Number: Must have at least one number (0-9).</p>
                <br></br>
                <p>2. Phone Number:</p>
                <p>Length: Must be exactly 10 digits long.</p>
                <p>
                  Format: Should not include any spaces, dashes, or parentheses.
                </p>
                <br></br>
                <p>3. Email Address:</p>
                <p>
                  Format: Must be in a valid email format (e.g.,
                  user@example.com).
                </p>
                <br></br>
                <p>4. Username:</p>
                <p>Length: Must be between 5 and 20 characters long.</p>
                <p>
                  Allowed Characters: Can include letters, numbers, and
                  underscores (_).
                </p>
              </div> */}

              <div className="registration-form">
                <h1 className="main-heading mb-3">Registration Form</h1>
                <br />

                <form onSubmit={handleSubmit}>
                  <div>
                    <label htmlFor="username">Username</label>
                    <input
                      type="text"
                      name="username"
                      placeholder="Username"
                      id="username"
                      required
                      autoComplete="off"
                      value={user.username}
                      onChange={handleInput}
                    />
                  </div>

                  <div>
                    <label htmlFor="email">Email</label>
                    <input
                      type="text"
                      name="email"
                      placeholder="hello123@world.com"
                      id="email"
                      required
                      autoComplete="off"
                      value={user.email}
                      onChange={handleInput}
                    />
                  </div>

                  <div>
                    <label htmlFor="phone">Phone</label>
                    <input
                      type="phoneNumber"
                      name="phone"
                      placeholder="986******8"
                      id="phone"
                      required
                      autoComplete="off"
                      value={user.phone}
                      onChange={handleInput}
                    />
                  </div>

                  <div>
                    <label htmlFor="password">Password</label>
                    <input
                      type="Password"
                      name="password"
                      placeholder="hi1****"
                      id="password"
                      required
                      autoComplete="off"
                      value={user.password}
                      onChange={handleInput}
                    />
                  </div>

                  <br />
                  <button type="submit" className="btn btn-submit">
                    Register Now
                  </button>
                </form>
              </div>
            {/* </div> */}
          </div>
        </main>
      </section>
    </>
  );
};
