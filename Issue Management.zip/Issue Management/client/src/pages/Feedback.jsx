import { useState } from "react";
// import { useNavigate } from "react-router-dom";

const defaultFormData = {
  overallExperience: 1, // Change to match the Mongoose model
  designRating: 1,
  loadingTimeRating: 1,
  comments: "",
};

export const FeedbackForm = () => {
  const [overallExperience, setOverallExperience] = useState(defaultFormData.overallExperience);
  const [designRating, setDesignRating] = useState(defaultFormData.designRating);
  const [loadingTimeRating, setLoadingTimeRating] = useState(defaultFormData.loadingTimeRating);
  const [comments, setComments] = useState(defaultFormData.comments);

  // const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    const feedbackData = {
      overallExperience, // Use correct naming
      designRating,
      loadingTimeRating,
      comments,
    };

    try {
      const response = await fetch("http://localhost:5000/api/feedback/feedback", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(feedbackData),
      });

      if (response.ok) {
        // Reset form data to default values
        setOverallExperience(defaultFormData.overallExperience);
        setDesignRating(defaultFormData.designRating);
        setLoadingTimeRating(defaultFormData.loadingTimeRating);
        setComments(defaultFormData.comments);
        alert("Message sent successfully");
      } else {
        alert("Message not sent");
      }
    } catch (error) {
      alert("Message not sent");
      console.log(error);
    }
  };

  return (
    <section className="feedback-section">
      <div>
        <h1>Feedback Form</h1>
      </div>
      <div>
        <p>
          Please rate us on various aspects from 1 to 5 stars, with 5 being excellent and 1 being poor.
          We’d also love to hear your thoughts—feel free to leave a brief comment to help us improve!
        </p>
      </div>
      <form onSubmit={handleSubmit}>
        <div className="rating-group">
          <label>Overall Experience:</label>
          {[1, 2, 3, 4, 5].map((rate) => (
            <label key={`overall-${rate}`}>
              <input
                type="radio"
                name="overallExperience"
                value={rate} // Correctly set the value
                checked={overallExperience === rate}
                onChange={() => setOverallExperience(rate)}
              />
              {rate}
            </label>
          ))}
        </div>

        <div className="rating-group">
          <label>Design:</label>
          {[1, 2, 3, 4, 5].map((rate) => (
            <label key={`design-${rate}`}>
              <input
                type="radio"
                name="designRating"
                value={rate} // Correctly set the value
                checked={designRating === rate}
                onChange={() => setDesignRating(rate)}
              />
              {rate}
            </label>
          ))}
        </div>

        <div className="rating-group">
          <label>Loading Time:</label>
          {[1, 2, 3, 4, 5].map((rate) => (
            <label key={`loading-${rate}`}>
              <input
                type="radio"
                name="loadingTimeRating"
                value={rate} // Correctly set the value
                checked={loadingTimeRating === rate}
                onChange={() => setLoadingTimeRating(rate)}
              />
              {rate}
            </label>
          ))}
        </div>

        <div className="feedback">
          <label>Comments:</label>
          <textarea
            className="feedback-textarea"
            value={comments}
            onChange={(e) => setComments(e.target.value)}
            rows="13"
          />
        </div>

        <div className="feedback">
          <button type="submit" className="feedback-button">Submit Feedback</button>
        </div>
      </form>
    </section>
  );
};


