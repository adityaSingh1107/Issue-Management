export const About = () => {
  return (
    <>
      <main>
        <section className="section-hero">
          <div className="container grid grid-two-cols">
            <div className="about-content">
              <br />
              <h1>About Our Issue Management Tools</h1>
              <br />
              <p>
                Our Mission: We strive to streamline issue reporting and
                resolution processes, ensuring efficiency and transparency in
                addressing concerns.
              </p>
              <br />

              <p>
                Our Vision: To simplify and enhance the way issues are reported,
                tracked, and resolved, creating a more organized and responsive
                environment.
              </p>
              <br />

              <p>
                What We Do: We provide a user-friendly platform for individuals
                and organizations to log, track, and manage issues effectively.
              </p>
              <br />

              <p>
                Why Choose Us: User-Centric Design: Focused on delivering a
                seamless experience for all users. Robust Security: Ensuring
                data protection and privacy. Reliable Support: Dedicated team to
                assist with any questions or issues.
              </p>
            </div>

            <div className="home-image">
              <img
                src="/images/about.png"
                alt="Welcome to About"
                width="400"
                height="400"
              />
            </div>
          </div>
        </section>
      </main>
    </>
  );
};
