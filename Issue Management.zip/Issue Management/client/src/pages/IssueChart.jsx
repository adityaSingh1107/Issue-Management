// // import { useEffect, useState } from "react";
// // import { useParams } from "react-router-dom";
// // import { PieChart, Pie, Sector, Cell, ResponsiveContainer } from 'recharts';

// // export const IssuesDashboard = () => {
// //   const { id } = useParams();
// //   const [issues, setIssues] = useState([]);
// //   const [assigneesCount, setAssigneesCount] = useState(0);

// //   useEffect(() => {
// //     // Fetch issues data
// //     const fetchIssues = async () => {
// //       try {
// //         const response = await fetch("http://localhost:5000/api/admin/issues", {
// //           method: "GET",
// //           headers: {
// //             Authorization: `Bearer ${localStorage.getItem("token")}`,
// //           },
// //         });

// //         if (response.ok) {
// //           const data = await response.json();
// //           if (Array.isArray(data)) {
// //             setIssues(data);
// //           } else {
// //             console.error('Unexpected data format for issues:', data);
// //           }
// //         } else {
// //           console.error('Error fetching issues:', response.statusText);
// //         }
// //       } catch (error) {
// //         console.error('Error fetching issues:', error);
// //       }
// //     };

// //     fetchIssues();
// //   }, [id]);

// //   useEffect(() => {
// //     // Fetch assignees data
// //     const fetchAssignees = async () => {
// //       try {
// //         const response = await fetch("http://localhost:5000/api/assignee", {
// //           method: "GET",
// //           headers: {
// //             Authorization: `Bearer ${localStorage.getItem("token")}`,
// //             "Content-Type": "application/json",
// //           },
// //         });

// //         if (response.ok) {
// //           const data = await response.json();
// //           setAssigneesCount(data.length);
// //         } else {
// //           console.error('Error fetching assignees:', response.statusText);
// //         }
// //       } catch (error) {
// //         console.error('Error fetching assignees:', error);
// //       }
// //     };

// //     fetchAssignees();
// //   }, []);

// //   const getTotalIssues = () => {
// //     return issues.length;
// //   };

// //   return (
// //     <div className="summary">
// //       <p>Total Issues: {getTotalIssues()}</p>
// //       <p>Total Assignees: {assigneesCount}</p>
// //     </div>
// //   );
// // };

// import { useEffect, useState } from "react";
// import { useParams } from "react-router-dom";
// import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';

// export const IssuesDashboard = () => {
//   const { id } = useParams();
//   const [issues, setIssues] = useState([]);
//   const [assignees, setAssignees] = useState([]);
//   const [assigneesCount, setAssigneesCount] = useState(0);

//   useEffect(() => {
//     // Fetch issues data
//     const fetchIssues = async () => {
//       try {
//         const response = await fetch("http://localhost:5000/api/admin/issues", {
//           method: "GET",
//           headers: {
//             Authorization: `Bearer ${localStorage.getItem("token")}`,
//           },
//         });

//         if (response.ok) {
//           const data = await response.json();
//           if (Array.isArray(data)) {
//             setIssues(data);
//           } else {
//             console.error('Unexpected data format for issues:', data);
//           }
//         } else {
//           console.error('Error fetching issues:', response.statusText);
//         }
//       } catch (error) {
//         console.error('Error fetching issues:', error);
//       }
//     };

//     fetchIssues();
//   }, [id]);

//   useEffect(() => {
//     // Fetch assignees data
//     const fetchAssignees = async () => {
//       try {
//         const response = await fetch("http://localhost:5000/api/assignee", {
//           method: "GET",
//           headers: {
//             Authorization: `Bearer ${localStorage.getItem("token")}`,
//             "Content-Type": "application/json",
//           },
//         });

//         if (response.ok) {
//           const data = await response.json();
//           setAssignees(data);
//           setAssigneesCount(data.length);
//         } else {
//           console.error('Error fetching assignees:', response.statusText);
//         }
//       } catch (error) {
//         console.error('Error fetching assignees:', error);
//       }
//     };

//     fetchAssignees();
//   }, []);

//   // Process issues data for pie chart
//   const issueStatusData = issues.reduce((acc, issue) => {
//     const status = issue.status || 'Unknown'; // Default to 'Unknown' if no status
//     if (acc[status]) {
//       acc[status] += 1;
//     } else {
//       acc[status] = 1;
//     }
//     return acc;
//   }, {});

//   const pieData = Object.keys(issueStatusData).map(status => ({
//     name: status,
//     value: issueStatusData[status]
//   }));

//   // Process issues data for bar chart
//   const issuesByAssignee = issues.reduce((acc, issue) => {
//     const assignee = issue.assignee || 'Unassigned'; // Default to 'Unassigned' if no assignee
//     if (acc[assignee]) {
//       acc[assignee] += 1;
//     } else {
//       acc[assignee] = 1;
//     }
//     return acc;
//   }, {});

//   const barData = Object.keys(issuesByAssignee).map(assignee => ({
//     name: assignee,
//     issues: issuesByAssignee[assignee]
//   }));

//   return (
//     <div className="summary">
//       <p>Total Issues: {issues.length}</p>
//       <p>Total Assignees: {assigneesCount}</p>

//       <ResponsiveContainer width="100%" height={300}>
//         <PieChart>
//           <Pie
//             data={pieData}
//             dataKey="value"
//             nameKey="name"
//             outerRadius={100}
//             fill="#8884d8"
//             label
//           >
//             {pieData.map((entry, index) => (
//               <Cell key={`cell-${index}`} fill={index % 2 === 0 ? '#8884d8' : '#82ca9d'} />
//             ))}
//           </Pie>
//         </PieChart>
//       </ResponsiveContainer>

//       <ResponsiveContainer width="100%" height={300}>
//         <BarChart
//           data={barData}
//           margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
//         >
//           <XAxis dataKey="name" />
//           <YAxis />
//           <Tooltip />
//           <Legend />
//           <Bar dataKey="issues" fill="#8884d8" />
//         </BarChart>
//       </ResponsiveContainer>
//     </div>
//   );
// };

import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import {
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

export const IssuesDashboard = () => {
  const { id } = useParams();
  const [issues, setIssues] = useState([]);
  const [assignees, setAssignees] = useState([]);
  const [assigneesCount, setAssigneesCount] = useState(0);

  useEffect(() => {
    // Fetch issues data
    const fetchIssues = async () => {
      try {
        const response = await fetch("http://localhost:5000/api/admin/issues", {
          method: "GET",
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        });

        if (response.ok) {
          const data = await response.json();
          if (Array.isArray(data)) {
            setIssues(data);
          } else {
            console.error("Unexpected data format for issues:", data);
          }
        } else {
          console.error("Error fetching issues:", response.statusText);
        }
      } catch (error) {
        console.error("Error fetching issues:", error);
      }
    };

    fetchIssues();
  }, [id]);

  useEffect(() => {
    // Fetch assignees data
    const fetchAssignees = async () => {
      try {
        const response = await fetch("http://localhost:5000/api/assignee", {
          method: "GET",
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json",
          },
        });

        if (response.ok) {
          const data = await response.json();
          setAssignees(data);
          setAssigneesCount(data.length);
        } else {
          console.error("Error fetching assignees:", response.statusText);
        }
      } catch (error) {
        console.error("Error fetching assignees:", error);
      }
    };

    fetchAssignees();
  }, []);

  const totalIssues = issues.length;

  // Data for Pie Chart
  const pieData = [
    { name: "Total Issues Register", value: totalIssues },
    { name: "Total Issue Attempted", value: assigneesCount },
  ];

  // Data for Bar Chart
  const barData = [
    { name: "Total Issues Register", count: totalIssues },
    { name: "Total Issue Attempted", count: assigneesCount },
  ];

  return (
    <div className="issues-dashboard">
      <div className="summary">
        {/* <p>Total Issues Register: {totalIssues}</p>
        <p>Total Issue Attempted: {assigneesCount}</p> */}
        <p>Welcome to ISSUE TRACKING...!</p> 
        <p>We’re thrilled you’re here.</p>
      </div>

      <div className="issues-dashboard__charts">
        <div className="issues-dashboard__chart issues-dashboard__pie-chart">
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={pieData}
                dataKey="value"
                nameKey="name"
                outerRadius={100}
                fill="#8884d8"
                label
              >
                {pieData.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={index === 0 ? "#d42215" : "#82ca9d"}
                  />
                ))}
              </Pie>
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="issues-dashboard__chart issues-dashboard__bar-chart">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart
              data={barData}
              margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
            >
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="count" fill="#8884d8" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
