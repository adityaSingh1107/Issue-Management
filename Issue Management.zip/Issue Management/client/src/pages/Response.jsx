// import { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";

// export const Response = () => {
//   const [response, setResponse] = useState([]);
//   const [searchTerm, setSearchTerm] = useState("");

//   const navigate = useNavigate();

//     const getAllResponse = async () => {
//       try {
//         const response = await fetch("http://localhost:5000/api/assignee", {
//           method: "GET",
//           headers: {
//             Authorization: `Bearer ${localStorage.getItem("token")}`,
//             "Content-Type": "application/json", 
//           },
//         });
//         console.log(" responsefrom Response :", response);  

//         if (response.ok) {
//           const data = await response.json();
//           setResponse(data);
//         } else {
//           console.error('Error fetching data:', response.statusText);
//         }
//       } catch (error) {
//         console.error('Error:', error);
//       }
//     };


//   useEffect(() => {
//     getAllResponse();
//   }, []);

//   const handleSearch = (e) => {
//     setSearchTerm(e.target.value.toLowerCase());
//   };

//   const handleEdit = () => {
//     alert("edit");
//   };

//   const handleOk = () => {
//     navigate('/feedback');    
//   };

//   const handleDownload = (fileName) => {
//     const url = `http://localhost:5000/uploads/${fileName}`;
//     window.location.href = url; 
//   };

//   const filteredResponse = response.filter((response)=>
//     response.username.toLowerCase().includes(searchTerm) ||
//   response.type.toLowerCase().includes(searchTerm)
//   )

//   return (
//     <>
//       <section className="user-response-section">
//         <div className="container-response-header">
//           <header>
//             <h1> Response Page</h1>
//             <input
//               type="text"
//               placeholder="Search(username, Type)"
//               value={searchTerm}
//               onChange={handleSearch}
//             />
//           </header>
//         </div>
//         <div className="container user-response">
//           <table>
//             <thead>
//               <tr>
//                 <th>Issue Date</th>
//                 <th>Username</th>
//                 <th>Type</th>
//                 <th>Assign To</th>
//                 <th>Query</th>
//                 <th>Priority Level</th>
//                 <th>Location</th>
//                 <th>Comment</th>
//                 <th>Attachments</th>
//                 <th>Actions</th>
//               </tr>
//             </thead>
//             <tbody>
//               {filteredResponse.map((curResponse, index) => (
//                 <tr key={index}>
//                   <td>{curResponse.issueDate}</td>
//                   <td>{curResponse.username}</td>
//                   <td>{curResponse.type}</td>
//                   <td>{curResponse.assignTo}</td>
//                   <td>{curResponse.query}</td>
//                   <td>{curResponse.priorityLevel}</td>
//                   <td>{curResponse.location}</td>
//                   <td>{curResponse.comment}</td>
//                   <td>
//                   {curResponse.attachments && curResponse.attachments.length > 0 ? (
//                     <ul>
//                       {curResponse.attachments.map((file, index) => (
//                         <li key={index}>
//                           <button onClick={() => handleDownload(file)}>
//                             Download
//                           </button>
//                         </li>
//                       ))}
//                     </ul>
//                   ) : (
//                     <p>No attachments</p>
//                   )}
//                 </td>
//                   <td>
//                     <button onClick={() => handleEdit(curResponse._id)}>Edit</button>
//                     <button onClick={() => handleOk(curResponse._id)}>OK</button>
//                   </td>
//                 </tr>
//               ))}
//             </tbody>
//           </table>
//         </div>
//       </section>
//     </>
//   );
// };


import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

export const Response = () => {
  const [response, setResponse] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [currentResponse, setCurrentResponse] = useState(null);
  const [comment, setComment] = useState("");

  const navigate = useNavigate();

  const getAllResponse = async () => {
    try {
      const response = await fetch("http://localhost:5000/api/assignee", {
        method: "GET",
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
          "Content-Type": "application/json",
        },
      });

      if (response.ok) {
        const data = await response.json();
        setResponse(data);
      } else {
        console.error('Error fetching data:', response.statusText);
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  useEffect(() => {
    getAllResponse();
  }, []);

  const handleSearch = (e) => {
    setSearchTerm(e.target.value.toLowerCase());
  };

  const handleEdit = (responseData) => {
    setCurrentResponse(responseData);
    setComment(""); // Clear previous comment
    setModalOpen(true);
  };

  const handleCommentChange = (e) => {
    setComment(e.target.value);
  };

  const handleSubmit = async () => {
    if (!currentResponse) return;

    const updatedResponse = {
      ...currentResponse,
      comment, // Include the new comment
    };

    try {
      const response = await fetch("http://localhost:5000/api/assignee", {
        method: "PUT", // Assuming you're updating an existing response
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(updatedResponse),
      });

      if (response.ok) {
        setComment(""); // Clear the comment input
        setModalOpen(false);
        getAllResponse(); // Refresh the response list
      } else {
        console.error('Error updating response:', response.statusText);
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const handleDownload = (fileName) => {
    const url = `http://localhost:5000/uploads/${fileName}`;
    window.location.href = url;
  };

  const filteredResponse = response.filter((res) =>
    res.username.toLowerCase().includes(searchTerm) ||
    res.type.toLowerCase().includes(searchTerm)
  );

  return (
    <>
      <section className="user-response-section">
        <div className="container-response-header">
          <header>
            <h1>Response Page</h1>
            <input
              type="text"
              placeholder="Search(username, Type)"
              value={searchTerm}
              onChange={handleSearch}
            />
          </header>
        </div>
        <div className="container user-response">
          <table>
            <thead>
              <tr>
                <th>Issue Date</th>
                <th>Username</th>
                <th>Type</th>
                <th>Assign To</th>
                <th>Query</th>
                <th>Priority Level</th>
                <th>Location</th>
                <th>Comment</th>
                <th>Attachments</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredResponse.map((curResponse, index) => (
                <tr key={index}>
                  <td>{curResponse.issueDate}</td>
                  <td>{curResponse.username}</td>
                  <td>{curResponse.type}</td>
                  <td>{curResponse.assignTo}</td>
                  <td>{curResponse.query}</td>
                  <td>{curResponse.priorityLevel}</td>
                  <td>{curResponse.location}</td>
                  <td>{curResponse.comment}</td>
                  <td>
                    {curResponse.attachments && curResponse.attachments.length > 0 ? (
                      <ul>
                        {curResponse.attachments.map((file, index) => (
                          <li key={index}>
                            <button onClick={() => handleDownload(file)}>Download</button>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p>No attachments</p>
                    )}
                  </td>
                  <td>
                    {/* <button onClick={() => handleEdit(curResponse)}>Edit</button> */}
                    <button onClick={() => navigate('/feedback')}>OK</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {modalOpen && (
        <div className="modal">
          <div className="modal-content">
            <h2>Edit Comment</h2>
            <textarea
              value={comment}
              onChange={handleCommentChange}
              placeholder="Add your comment here"
            />
            <button onClick={handleSubmit}>Submit</button>
            <button onClick={() => setModalOpen(false)}>Cancel</button>
          </div>
        </div>
      )}
    </>
  );
};

