import { useState} from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../store/auth";

const URL = "http://localhost:5000/api/auth/login";

export const Login = () => {
  const [user, setUser] = useState({
    email: "",
    password: "",
  });


  const navigate = useNavigate();
  const { storeTokenInLS } = useAuth();

  const handleInput = (e) => {
    let name = e.target.name;
    let value = e.target.value;
    setUser({
      ...user,
      [name]: value,
    });
  };


  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const response = await fetch(URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(user),
      });
  
      if (response.ok) {
        const res_data = await response.json();
        storeTokenInLS(res_data.token);
  
        setUser({ email: "", password: "" });
        // navigate("/");
      // Check the isAssignee property and navigate accordingly
      if (res_data.assignee) {
        navigate("/assignee");
      } else if (res_data.manager) {
        navigate("/admin/users");
      } else {
        navigate("/");
      }
      } else {
        alert("Invalid Credentials");
      }
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <>
      <section>
        <main>
          <div className="section-login">
              <div className="login-form">
                <h1 className="main-heading-login">Login Page</h1>
                <br />
                <form onSubmit={handleSubmit} className="login-form-main">
                  <div>
                    <label htmlFor="email">Email</label>
                    <input
                      type="text"
                      name="email"
                      placeholder="hello123@world.com"
                      id="email"
                      required
                      autoComplete="off"
                      value={user.email}
                      onChange={handleInput}
                    />
                  </div>

                  <div>
                    <label htmlFor="password">Passowrd</label>
                    <input
                      type="password"
                      name="password"
                      placeholder="hi1****"
                      id="password"
                      required
                      autoComplete="off"
                      value={user.password}
                      onChange={handleInput}
                    />
                  </div>

                  <br />
                  <button type="submit" className="login-btn-submit">
                    Login Now
                  </button>
                </form>
              </div>
          </div>
        </main>
      </section>
    </>
  );
};
