import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { useAuth } from "../store/auth";
import { useNavigate } from "react-router-dom";

export const AdminQuery = () => {
  const navigate = useNavigate();

  const { storeTokenInLS } = useAuth();
  const { id } = useParams();
  // const [issue, setIssue] = useState(null);
  const [issue, setIssue] = useState([]);
  const [comment, setComment] = useState({ comment: "" });
  const [files, setFiles] = useState([]);
  const [selectedIssue, setSelectedIssue] = useState(null);

  useEffect(() => {
    fetch("http://localhost:5000/api/admin/issues", {
      method: "GET",
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
    })
      .then((response) => response.json())
      .then((data) => {
        if (Array.isArray(data)) {
          setIssue(data);
        } else {
          console.error('Unexpected data format:', data);
        }
      })
      .catch((error) => console.error("Error fetching issue:", error));
  }, [id]);
const handleFileChange = (e) => {
  setFiles(Array.from(e.target.files));
};

const handleInput = (e) => {
  const { name, value } = e.target;
  setComment(value);
};

const handleSubmit = async (e) => {
  e.preventDefault();

  if (!selectedIssue) {
    alert("No issue selected for update");
    return;
  }

  const formData = new FormData();
  formData.append("username", selectedIssue.username);
  formData.append("assignTo", selectedIssue.assignTo);
  formData.append("comment", comment);
  formData.append("issueDate", selectedIssue.issueDate);
  formData.append("type", selectedIssue.type);
  formData.append("query", selectedIssue.query);
  formData.append("priorityLevel", selectedIssue.priorityLevel);
  formData.append("location", selectedIssue.location);

  files.forEach((file) => {
    formData.append("attachments", file);
  });

  try {
    const response = await fetch("http://localhost:5000/api/assignee", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
      body: formData,
    });

    if (response.ok) {
      setFiles([]);
      setComment('');
      setSelectedIssue(null);
      alert("Response Updated Successfully");
    } else {
      const errorData = await response.json();
      console.error('Error response:', errorData);
      alert("Response not Updated");
    }
  } catch (error) {
    console.error("Error submitting form: ", error);
  }
};

const handleDownload = (fileName) => {
  const url = `http://localhost:5000/uploads/${fileName}`;
  window.location.href = url; 
};

const handleEdit = (issue) => {
  setSelectedIssue(issue);
  setComment(issue.comment || ''); 
};

if (issue.length === 0) return <p>Loading...</p>;

return (
  <section className="assignee-response-container">
    <div className="assignee-response-header">
      <header>
        <h1>Admin Issues Page</h1>
      </header>
    </div>
    <div className="assignee-response-content">
      <table>
        <thead>
          <tr>
            <th>Date</th>
            <th>Priority</th>
            <th>Username</th>
            <th>Assign To</th>
            <th>Issue Type</th>
            <th>Issue</th>
            <th>Attachments</th>
            {/* <th>Actions</th> */}
          </tr>
        </thead>
        <tbody>
          {issue.map((issues, index) => (
            <tr key={index}>
              <td>{issues.issueDate}</td>
              <td>{issues.priorityLevel}</td>
              <td>{issues.username}</td>
              <td>{issues.assignTo}</td>
              <td>{issues.type}</td>
              <td>{issues.query}</td>
              <td>
                {issues.attachments && issues.attachments.length > 0 ? (
                  <ul>
                    {issues.attachments.map((file, index) => (
                      <li key={index}>
                        <button onClick={() => handleDownload(file)}>
                          Download
                        </button>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p>No attachments</p>
                )}
              </td>
              <td>
                {/* <button onClick={() => handleEdit(issues)}>Edit</button> */}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {selectedIssue && (
        <div className="edit-modal-assignee">
          <div className="edit-modal-content-assignee">
            <h2>Edit Issue</h2>
            <form onSubmit={handleSubmit}>
              <div>
                <label htmlFor="comment">Response</label>
                <textarea
                  name="comment"
                  id="comment"
                  cols="78"
                  rows="13"
                  autoComplete="off"
                  value={comment}
                  onChange={handleInput}
                  required
                ></textarea>
              </div>
              <div>
                <label htmlFor="attachment">Attach Files</label>
                <input
                  type="file"
                  id="attachment"
                  name="attachments"
                  onChange={handleFileChange}
                  multiple
                />
              </div>
              <div className="edit-modal-buttons-assignee">
                {/* <button type="submit">Submit</button> */}
                <button
                  type="button"
                  onClick={() => setSelectedIssue(null)}
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  </section>
);
};
