import { useState, useEffect } from "react";

const getCurrentDate = () => {
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, "0");
  const day = String(today.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
};

const defaultIssueFormData = {
  // username: "",
  // userId: "",
  query: "",
  type: "",
  assignTo: "",
  priorityLevel: "",
  location: "",
  issueDate: getCurrentDate(),
};

export const Issue = () => {
  const [issue, setIssue] = useState(defaultIssueFormData);
  const [files, setFiles] = useState([]);
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);

  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        const response = await fetch("http://localhost:5000/api/auth/user", {
          method: "GET",
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        });
        const userData = await response.json();
        if (userData) {
          setIssue((prev) => ({
            ...prev,
            userId: userData.userId,
            username: userData.username,
          }));
        }
      } catch (error) {
        console.error("Error fetching current user:", error);
      }
    };


    const fetchUsers = async () => {
      try {
        const response = await fetch("http://localhost:5000/api/admin/users", {
          method: "GET",
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        });
        const data = await response.json();
        if (Array.isArray(data)) {
          const assignees = data.filter((user) => user.isAssignee);
          setUsers(assignees);
        } else {
          console.error("Expected data to be an array but got:", data);
        }
      } catch (error) {
        console.error("Error fetching users:", error);
      }
    };

    fetchCurrentUser();
    fetchUsers();
  }, []);

  const handleFileChange = (e) => {
    setFiles(Array.from(e.target.files));
  };

  const handleInput = (e) => {
    const name = e.target.name;
    const value = e.target.value;

    if (name === "assignTo") {
      const selectedUser = users.find((user) => user.userId === value);
      setSelectedUser(selectedUser);
    }

    setIssue({
      ...issue,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append("username", issue.username);
    formData.append("userId", issue.userId);
    formData.append("query", issue.query);
    formData.append("type", issue.type);
    formData.append("assignTo", issue.assignTo);
    formData.append("priorityLevel", issue.priorityLevel);
    formData.append("issueDate", issue.issueDate);
    formData.append("location", issue.location);

    files.forEach((file) => {
      formData.append("attachments", file);
    });

    try {
      const response = await fetch("http://localhost:5000/api/issues/Issue", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
        body: formData,
      });

      if (response.ok) {
        setIssue(defaultIssueFormData);
        setFiles([]);
        alert("Issue Registered Successfully");
      } else {
        alert("Issue not Registered");
      }
    } catch (error) {
      console.error("Error submitting form: ", error);
    }
  };

  return (
    <div className="main-div-issue">
      <section id="issueForm">
        <main>
          <div className="title">
            <h1>ISSUE REGISTRATION FORM</h1>
          </div>
          <div className="query-form">
            <form onSubmit={handleSubmit}>
              <div className="date-box">
                <label>
                  Date
                  <p>{issue.issueDate}</p>
                </label>
              </div>

              <label>
                Username
                {/* <p>{issue.username}</p> */}
                <input
                  name="username"
                  type="text"
                  id="name"
                  value={issue.username}
                  // onChange={handleInput}
                  readOnly
                  // required
                />
              </label>

              
              <label>
                User ID
                <input
                  name="userId"
                  type="text"
                  id="userId"
                  value={issue.userId}
                  readOnly
                />
              </label>

              <label>
                Assign To
                <select
                  name="assignTo"
                  id="fordev"
                  value={issue.assignTo}
                  onChange={handleInput}
                  required
                >
                  <option value="">Select</option>
                  {users.map((user) => (
                    <option key={user.userId} value={user.userId}>
                      {user.username}
                    </option>
                  ))}
                </select>
              </label>
              {selectedUser && (
                <div className="selected-user-details">
                  <p>
                    <strong>Selected User ID:</strong> {selectedUser.userId}
                  </p>
                </div>
              )}

              <label>
                Priority Level
                <select
                  name="priorityLevel"
                  id="priority"
                  value={issue.priorityLevel}
                  onChange={handleInput}
                  required
                >
                  <option value="">Select</option>
                  <option value="Low">Low</option>
                  <option value="Medium">Medium</option>
                  <option value="High">High</option>
                  <option value="Urgent">Urgent</option>
                </select>
              </label>

              <label>
                Issue Type
                <select
                  name="type"
                  id="type"
                  value={issue.type}
                  onChange={handleInput}
                  required
                >
                  <option value="">Select</option>
                  <option value="Hardware">Hardware</option>
                  <option value="Heating">Heating</option>
                  <option value="Display">Display</option>
                  <option value="Hardisk">Hardisk</option>
                  <option value="Data Requirement">Data Requirement</option>
                  <option value="Other">Other</option>
                </select>
              </label>

              <div>
                <label htmlFor="query">Issue Description</label>
                <textarea
                  name="query"
                  id="query"
                  cols="30"
                  rows="9"
                  autoComplete="off"
                  value={issue.query}
                  onChange={handleInput}
                  placeholder="Enter your Complete issue..!"
                  required
                ></textarea>
              </div>

              <label>
                Location
                <select
                  name="location"
                  id="location"
                  value={issue.location}
                  onChange={handleInput}
                  required
                >
                  <option value="">Select</option>
                  <option value="Delhi">Delhi</option>
                  <option value="Mumbai">Mumbai</option>
                  <option value="Jamshdpur">Jamshdpur</option>
                  <option value="Ghaziabad">Ghaziabad</option>
                  <option value="Other">Other</option>
                </select>
              </label>

              <div>
                <label htmlFor="attachment">Attach Files</label>
                <input
                  type="file"
                  id="attachment"
                  name="attachments"
                  onChange={handleFileChange}
                  multiple
                />
              </div>
              <label>
                <div>
                  <button type="submit">Submit</button>
                </div>
              </label>
            </form>
          </div>
        </main>
      </section>
    </div>
  );
};
