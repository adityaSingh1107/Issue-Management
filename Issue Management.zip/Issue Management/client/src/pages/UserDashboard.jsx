import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";

export const IssueManager = () => {
  const { id } = useParams();
  const [issue, setIssue] = useState(null);
  const [comment, setComment] = useState( "" );
  const [files, setFiles] = useState([]);
  const [selectedIssue, setSelectedIssue] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    fetch("http://localhost:5000/api/admin/issues", {
      method: "GET",
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
    })
      // .then((response) => {
      //   // console.log(response);
      //   return response.json();
      // })
      // .then((data) => setIssue(data))
      // .catch((error) => console.error("Error fetching issue:", error));
      .then((response) => response.json())
      .then((data) => setIssue(data))
      .catch((error) => console.error("Error fetching issue:", error));
  }, [id]);

//   const handleFileChange = (e) => {
//     setFiles(Array.from(e.target.files));
//   };

  const handleInput = (e) => {
    console.log(e);
    const { name, value } = e.target;
    setComment((formData) => ({
      ...formData,
      [name]: value,
    }));
  };

  const handleSearch = (e) => {
    setSearchTerm(e.target.value.toLowerCase());
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append("username", issue.username);
    // formData.append("assignTo", issue.assignTo);
    // formData.append("comment", comment);

    files.forEach((file) => {
      formData.append("attachments", file);
    });

    try {
      const response = await fetch("http://localhost:5000/api/issues/Issue", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
        body: formData,
      });

      if (response.ok) {
        setFiles([]);
        alert("Issue Updated Successfully");
      } else {
        alert("Issue not Updated");
      }
    } catch (error) {
      console.error("Error submitting form: ", error);
    }
  };

  const handleDownload = (fileName) => {
    const url = `http://localhost:5000/uploads/${fileName}`;
    fetch(url, {
      method: "HEAD",
    })
      .then((response) => {
        if (response.ok) {
          window.location.href = url;
        } else {
          alert("No file attached");
        }
      })
      .catch((error) => {
        console.error("Error checking file:", error);
        alert("No file attached");
      });
  };

  const handleEdit = (issue) => {
    setSelectedIssue(issue);
    setComment(issue.comment || ""); 
  };

  if (!issue) return <p>Loading...</p>;


  // const filteredIssues = issue.filter((issue) =>
  //   issue.username.toLowerCase().includes(searchTerm) ||
  //   issue.type.toLowerCase().includes(searchTerm)
  // );
  
  const filteredIssues = issue.filter((issue) =>
    issue.username.toLowerCase().includes(searchTerm) ||
    issue.type.toLowerCase().includes(searchTerm)
  );

  return (
    <>
      <section className="assignee-response-container">
        <div className="assignee-response-header">
          <header>
            <h1> Registered Issues</h1>
            <input
              type="text"
              placeholder="Search(username, Type)"
              value={searchTerm}
              onChange={handleSearch}
            />
          </header>
        </div>
        <div className="assignee-response-content">
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Priority</th>
                <th>Username</th>
                <th>Assign To</th>
                <th>Issue Type</th>
                <th>Issue</th>
                <th>Attachments</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredIssues.map((issues, index) => (
                <tr key={index}>
                  <td>{issues.issueDate}</td>
                  <td>{issues.priorityLevel}</td>
                  <td>{issues.username}</td>
                  <td>{issues.assignTo}</td>
                  <td>{issues.type}</td>
                  <td>{issues.query}</td>
                  <td>
                    {issue.attachments && issue.attachments.length > 0 ? (
                      <ul>
                        {issue.attachments.map((file, idx) => (
                          <li key={idx}>
                            <span>{file}</span>
                            <button onClick={() => handleDownload(file)}>
                              Download
                            </button>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p>No attachments</p>
                    )}
                  </td>
                  <td>
                    <button onClick={() => handleEdit(issue)}>Edit</button>
                    {/* <button onClick={() => handleDelete(issue._id)}>Delete</button> */}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {selectedIssue && (
            <div className="edit-modal-assignee">
              <div className="edit-modal-content-assignee">
                <h2>Edit Issue</h2>
                <form onSubmit={handleSubmit}>
                  <label>
                    Priority Level
                    <select
                      name="priorityLevel"
                      id="priority"
                      //   value={issue.priorityLevel}
                      value={selectedIssue.priorityLevel || ""}
                      onChange={handleInput}
                      required
                    >
                      <option value="">Select</option>
                      <option value="Low">Low</option>
                      <option value="Medium">Medium</option>
                      <option value="High">High</option>
                      <option value="Urgent">Urgent</option>
                    </select>
                  </label>

                  <label>
                    Issue Type
                    <select
                      name="type"
                      id="type"
                      //   value={issue.type}
                      value={selectedIssue.type || ""}
                      onChange={handleInput}
                      required
                    >
                      <option value="">Select</option>
                      <option value="Hardware">Hardware</option>
                      <option value="Heating">Heating</option>
                      <option value="Display">Display</option>
                      <option value="Hardisk">Hardisk</option>
                      <option value="Data Requirement">Data Requirement</option>
                      <option value="Other">Other</option>
                    </select>
                  </label>

                  <div>
                    <label htmlFor="query">Issue Description</label>
                    <textarea
                      name="query"
                      id="query"
                      cols="30"
                      rows="9"
                      autoComplete="off"
                      //   value={issue.query}
                      value={selectedIssue.query || ""}
                      onChange={handleInput}
                      placeholder="Enter your Complete issue..!"
                      required
                    ></textarea>
                  </div>
                  <div className="edit-modal-buttons-assignee">
                    <button type="submit">Submit</button>
                    <button
                      type="button"
                      onClick={() => setSelectedIssue(null)}
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      </section>
    </>
  );
};
