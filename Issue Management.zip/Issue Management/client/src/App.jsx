import './App.css';

import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Home } from "./pages/Home";
import { About } from "./pages/About";
import { Login } from "./pages/Login";
import { Register } from "./pages/Register";
import { Contact } from "./pages/Contact";
import { Navbar } from "./components/Navbar";
import { Logout } from "./pages/Logout";
import { Error } from "./pages/Error";
import { Issue } from "./pages/IssueForm";
import { Footer } from "./components/footer/Footer";
import { AdminLayout } from "./components/layouts/Admin-Layout";
import { AdminUsers } from "./pages/Admin-Users";
import { AdminQuery } from "./pages/Admin-Query";
import { Response } from './pages/Response';
import { FeedbackForm } from './pages/Feedback';
import { AssigneeResponse } from './pages/Assignee-Response';
import { IssueManager } from './pages/UserDashboard';
import { IssuesDashboard } from './pages/IssueChart';



const App = () => {
  return (
    <>
    
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/issueform" element={<Issue />} />
          <Route path="/logout" element={<Logout />} />
          <Route path="/response" element={<Response />} />
          <Route path="/feedback" element={<FeedbackForm />} />
          <Route path="/assignee" element={<AssigneeResponse />} />
          <Route path="/issueManager" element={<IssueManager />} />
          <Route path="/dashboard" element={<IssuesDashboard />} />
          <Route path="/*" element={<Error />} />
          

          <Route path = "/admin" element = {<AdminLayout />} >
          <Route path = "users" element = {<AdminUsers/>} />
          <Route path = "issues" element = {<AdminQuery/>} />
          </Route>
        </Routes>
        <Footer />
      </BrowserRouter>
     

    </>
  )
};

export default App;