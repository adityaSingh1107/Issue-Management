import "./Footer.css";

export const Footer = () =>{
    return(
        <footer>
        <p>@internshipProject</p>
        </footer>
    )
}
