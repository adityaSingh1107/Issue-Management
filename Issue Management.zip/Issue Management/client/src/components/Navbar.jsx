// import { useState, useEffect } from "react";
// import { NavLink } from "react-router-dom";
// import "./Navbar.css";
// import { useAuth } from "../store/auth";
// import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import { faUser } from "@fortawesome/free-solid-svg-icons";

// export const Navbar = () => {
//   const { isLoggedIn, token } = useAuth();
//   const [dropdownOpen, setDropdownOpen] = useState(false);
//   const [userDetails, setUserDetails] = useState(null);

//   useEffect(() => {
//     if (isLoggedIn && token) {
//       const fetchUserDetails = async () => {
//         try {
//           const response = await fetch("http://localhost:5000/api/auth/user", {
//             headers: {
//               Authorization: `Bearer ${token}`,
//             },
//           });

//           console.log ({response});  

//           if (response.ok) {
//             const data = await response.json();
//             console.log("Fetched user details:", data);
//             setUserDetails(data);
//           } else {
//             console.error("Failed to fetch user details", response.status);
//           }
//         } catch (error) {
//           console.error("Error fetching user details:", error);
//         }
//       };
//       fetchUserDetails();
//     } else {
//       setUserDetails(null);
//     }
//   }, [isLoggedIn, token]);

//   const handleDropdownToggle = () => {
//     setDropdownOpen(!dropdownOpen);
//   };

//   return (
//     <header>
//       <div className="navbar">
//         <div className="logo-brand">
//           <NavLink to="/">
//             <h3>ISSUE MANAGEMENT</h3>
//           </NavLink>
//         </div>

//         <nav>
//           <ul>
//             <li>
//               <NavLink to="/">Home</NavLink>
//             </li>
//             {isLoggedIn ? (
//               <>
//                 <li>
//                   <NavLink to="/issueform">RegisterIssue</NavLink>
//                 </li>
//                 <li>
//                   <NavLink to="/issueManager">IssueDashboard</NavLink>
//                 </li>
//                 <li>
//                   <NavLink to="/response">Response</NavLink>
//                 </li>
//                 {userDetails && userDetails.assignee && (
//                   <li>
//                     <NavLink to="/assignee">Assignee</NavLink>
//                   </li>
//                 )}
//                 <li>
//                   <NavLink to="/logout">Logout</NavLink>
//                 </li>
//                 <li className="user-icon" onClick={handleDropdownToggle}>
//                   <FontAwesomeIcon icon={faUser} />
//                   {dropdownOpen && (
//                     <div className="dropdown-menu">
//                       <span className="user-icon">
//                         {userDetails ? (
//                           <>
//                             Hi, {userDetails.username}
//                             {/* console.log(username); */}
//                             <br />
//                             {userDetails.email}
//                             <br />
//                             {userDetails.userId}
//                           </>
//                         ) : (
//                           "Loading..."
//                         )}
//                       </span>
//                       <NavLink to="/" onClick={() => setDropdownOpen(false)}>
//                         Go to Home
//                       </NavLink>
//                     </div>
//                   )}
//                 </li>
//               </>
//             ) : (
//               <>
//                 <li>
//                   <NavLink to="/Contact">Contact</NavLink>
//                 </li>
//                 <li>
//                   <NavLink to="/Register">Register</NavLink>
//                 </li>
//                 <li>
//                   <NavLink to="/Login">Login</NavLink>
//                 </li>
//               </>
//             )}
//           </ul>
//         </nav>
//       </div>
//     </header>
//   );
// };




import { useState, useEffect } from "react";
import { NavLink } from "react-router-dom";
import "./Navbar.css";
import { useAuth } from "../store/auth";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faUser } from "@fortawesome/free-solid-svg-icons";

export const Navbar = () => {
  const { isLoggedIn, token } = useAuth();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [userDetails, setUserDetails] = useState(null);

  useEffect(() => {
    if (isLoggedIn && token) {
      const fetchUserDetails = async () => {
        try {
          const response = await fetch("http://localhost:5000/api/auth/user", {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          });

          if (response.ok) {
            const data = await response.json();
            setUserDetails(data);
          } else {
            console.error("Failed to fetch user details", response.status);
          }
        } catch (error) {
          console.error("Error fetching user details:", error);
        }
      };
      fetchUserDetails();
    } else {
      setUserDetails(null);
    }
  }, [isLoggedIn, token]);

  const handleDropdownToggle = () => {
    setDropdownOpen(!dropdownOpen);
  };

  return (
    <header>
      <div className="navbar">
        <div className="logo-brand">
          <NavLink to="/">
            <h3>ISSUE MANAGEMENT</h3>
          </NavLink>
        </div>

        <nav>
          <ul>
            <li>
              <NavLink to="/">Home</NavLink>
            </li>
            {isLoggedIn ? (
              <>
                <li>
                  <NavLink to="/issueform">RegisterIssue</NavLink>
                </li>
                <li>
                  <NavLink to="/issueManager">IssueDashboard</NavLink>
                </li>
                <li>
                  <NavLink to="/response">Response</NavLink>
                </li>
                {userDetails && userDetails.isAssignee && (  // Check for isAssignee
                  <li>
                    <NavLink to="/assignee">Assignee</NavLink>
                  </li>
                )}
                <li>
                  <NavLink to="/logout">Logout</NavLink>
                </li>
                <li className="user-icon" onClick={handleDropdownToggle}>
                  <FontAwesomeIcon icon={faUser} />
                  {dropdownOpen && (
                    <div className="dropdown-menu">
                      <span className="user-icon">
                        {userDetails ? (
                          <>
                            Hi, {userDetails.username}
                            <br />
                            {userDetails.email}
                            <br />
                            {userDetails.userId}
                          </>
                        ) : (
                          "Loading..."
                        )}
                      </span>
                      <NavLink to="/" onClick={() => setDropdownOpen(false)}>
                        Go to Home
                      </NavLink>
                    </div>
                  )}
                </li>
              </>
            ) : (
              <>
                <li>
                  <NavLink to="/Contact">Contact</NavLink>
                </li>
                <li>
                  <NavLink to="/Register">Register</NavLink>
                </li>
                <li>
                  <NavLink to="/Login">Login</NavLink>
                </li>
              </>
            )}
          </ul>
        </nav>
      </div>
    </header>
  );
};
