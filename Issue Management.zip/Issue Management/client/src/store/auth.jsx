import { createContext, useContext, useEffect} from "react";
import { useState } from "react";

export const AuthContext = createContext();

// eslint-disable-next-line react/prop-types
export const AuthProvider = ({ children }) => {

    const [token,setToken] = useState(localStorage.getItem("token"));
    const [user, setUser] = useState(null);

    // const authorizationToken = Bearer ${token};

    const storeTokenInLS = ( serverToken ) => {
         localStorage.setItem("token", serverToken);
         setToken(serverToken);
    };

    const removeTokenFromLS = () => {
        localStorage.removeItem("token");
        // setToken("");
        setToken(null);
        setUser(null);
    };

    //Logout Tackling
    const LogoutUser = () =>{
        removeTokenFromLS();
        // setToken("");
        // return localStorage.removeItem('token');
    };

    
    const userAuthentication = async() => {
        if (!token) {
            return; 
        }

        const authorizationToken = `Bearer ${token}`;
        
        try {
            const response = await fetch("http://localhost:5000/api/auth/user", {
                method: "GET",
                headers: {
                    Authorization: authorizationToken,
                },
            });

            if(response.ok){
                const data = await response.json();
                setUser(data.userData);
            }else {
                LogoutUser();
            }
        } catch (error) {
          console.error("Error fetching user data", error);
          LogoutUser();  
        }
    };

    useEffect(() => {
        userAuthentication();
    // }, [authorizationToken]);
    }, [token]);

    const isLoggedIn = !!token;
    // console.log("isLoggedIn",isLoggedIn);


    return( <AuthContext.Provider value= {{isLoggedIn, storeTokenInLS, removeTokenFromLS, LogoutUser, user, token}}>
        {children}
    </AuthContext.Provider>
    );
};

export const useAuth = () => {
    const authContextValue = useContext(AuthContext);
    if (!authContextValue) {
        throw new Error("useAuth used outside of the Provider");
    }
    return authContextValue;
}

